import numpy as np
import os

def hide_message(dct_dir, message, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    message_bits = ''.join(format(ord(c), '08b') for c in message)
    bit_idx = 0

    # Đọc khung hình duy nhất để nhúng tin
    scene_changes = np.load(f'{dct_dir}/scene_changes.npy')
    if len(scene_changes) == 0:
        print("No frame available for embedding")
        return []
    print(f"Frame to embed message: {scene_changes[0]}")

    dct_files = sorted([f for f in os.listdir(dct_dir) if f.endswith('.npy') and f != 'scene_changes.npy'])
    total_files = len(dct_files)
    print(f"Total DCT files to process: {total_files}")

    frames_used = []  # Lưu khung hình đã sử dụng để nhúng tin
    for idx, frame_file in enumerate(dct_files):
        dct_frame = np.load(f'{dct_dir}/{frame_file}')
        
        # Chỉ nhúng tin vào khung hình được chọn (có sự khác biệt lớn nhất)
        if idx == scene_changes[0] and bit_idx < len(message_bits):
            frames_used.append(idx)
            for i in range(dct_frame.shape[0]):
                for j in range(dct_frame.shape[1]):
                    if bit_idx < len(message_bits):
                        val = int(dct_frame[i, j])
                        val = val & 0xFE  # Xóa bit LSB
                        bit_to_embed = int(message_bits[bit_idx])
                        val = val | bit_to_embed  # Nhúng bit vào LSB
                        dct_frame[i, j] = val
                        bit_idx += 1
                    else:
                        break
                if bit_idx >= len(message_bits):
                    break
        
        np.save(f'{output_dir}/{frame_file}', dct_frame)
        if (idx + 1) % 100 == 0:
            print(f"Processed {idx + 1}/{total_files} DCT files for hiding message")

    print(f"Message hiding completed. Frame used for embedding: {frames_used}")
    return frames_used

if __name__ == '__main__':
    hide_message('dct', 'hello', 'stego_dct')