import cv2
import numpy as np
import os
import pywt

def normalize_and_reconstruct(frames_dir, stego_dct_dir, output_video, fps=30):
    alpha, beta = 0.9, 0.1  # alpha + beta = 1
    frames = sorted([f for f in os.listdir(frames_dir) if f.endswith('.png')])
    stego_dcts = sorted([f for f in os.listdir(stego_dct_dir) if f.endswith('.npy') and f != 'scene_changes.npy'])
    
    print(f"Number of frames: {len(frames)}")
    print(f"Number of stego_dcts: {len(stego_dcts)}")
    if len(frames) != len(stego_dcts):
        raise ValueError("Mismatch between number of frames and stego_dct files")

    height, width = cv2.imread(f'{frames_dir}/{frames[0]}').shape[:2]
    out = cv2.VideoWriter(output_video, cv2.VideoWriter_fourcc(*'mp4v'), fps, (width, height))
    
    for idx, (frame_file, dct_file) in enumerate(zip(frames, stego_dcts)):
        # Đọc khung hình gốc
        frame = cv2.imread(f'{frames_dir}/{frame_file}')
        frame_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY).astype(float)

        # Áp dụng DWT cho khung hình gốc (C(p, q))
        coeffs = pywt.dwt2(frame_gray, 'haar')
        LL, (LH, HL, HH) = coeffs

        # Đọc hệ số DCT đã nhúng tin (R(p, q))
        dct = np.load(f'{stego_dct_dir}/{dct_file}')
        norm_dct = dct / np.max(np.abs(dct))  # Chuẩn hóa R(p, q) về [0, 1]

        # Kiểm tra và điều chỉnh kích thước
        if LL.shape != norm_dct.shape:
            norm_dct = cv2.resize(norm_dct, (LL.shape[1], LL.shape[0]))

        # Kết hợp theo công thức 4.20: S(p, q) = alpha * C(p, q) + beta * R(p, q)
        combined_LL = alpha * LL + beta * norm_dct

        # Tái tạo khung hình bằng IDWT
        coeffs_reconstructed = (combined_LL, (LH, HL, HH))
        frame_reconstructed = pywt.idwt2(coeffs_reconstructed, 'haar')
        
        frame_reconstructed = cv2.resize(frame_reconstructed, (width, height))
        frame_reconstructed = np.clip(frame_reconstructed, 0, 255).astype(np.uint8)
        frame_reconstructed = cv2.cvtColor(frame_reconstructed, cv2.COLOR_GRAY2BGR)
        
        out.write(frame_reconstructed)
        if (idx + 1) % 100 == 0:
            print(f"Processed {idx + 1}/{len(frames)} frames for video reconstruction")
    
    out.release()
    print("Video reconstruction completed (no audio)")

if __name__ == '__main__':
    normalize_and_reconstruct('frames', 'stego_dct', 'stego_video_no_audio.mp4', fps=30)