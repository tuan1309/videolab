import numpy as np
import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

def extract_message(stego_dct_dir, max_bits=40, output_file='extracted_message.txt'):
    print("Extracting message from stego DCT coefficients...")

    scene_changes = np.load('dct/scene_changes.npy')
    print(f"Frames with embedded message: {scene_changes}")

    stego_files = sorted([f for f in os.listdir(stego_dct_dir) if f.endswith('.npy') and f != 'scene_changes.npy'])
    total_files = len(stego_files)
    print(f"Total stego files to process: {total_files}")

    extracted_bits = []
    frames_to_extract_idx = 0
    frames_extracted = []  # Lưu danh sách các khung hình đã trích xuất

    for idx, stego_file in enumerate(stego_files):
        if frames_to_extract_idx < len(scene_changes) and idx == scene_changes[frames_to_extract_idx]:
            dct_frame = np.load(f'{stego_dct_dir}/{stego_file}')
            frames_extracted.append(idx)
            for i in range(dct_frame.shape[0]):
                for j in range(dct_frame.shape[1]):
                    if len(extracted_bits) < max_bits:
                        bit = int(dct_frame[i, j]) & 1
                        extracted_bits.append(str(bit))
                    else:
                        break
                if len(extracted_bits) >= max_bits:
                    break
            frames_to_extract_idx += 1

        if len(extracted_bits) >= max_bits:
            break
        if (idx + 1) % 100 == 0:
            print(f"Processed {idx + 1}/{total_files} stego files for message extraction")

    print(f"Frames used for extraction: {frames_extracted}")
    message_bits = ''.join(extracted_bits)
    print(f"Extracted bits: {message_bits}")

    message = ''
    for i in range(0, len(message_bits), 8):
        byte = message_bits[i:i+8]
        if len(byte) == 8:
            char_code = int(byte, 2)
            print(f"Byte {i//8 + 1}: {byte} -> {char_code} -> {chr(char_code) if char_code != 0 else 'END'}")
            if char_code == 0:
                break
            try:
                message += chr(char_code)
            except UnicodeEncodeError:
                message += '?'
    
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write("Extracted bits:\n" + message_bits + '\n')
        f.write("\nExtracted message:\n" + message + '\n')

    print(f"Message extracted and saved to: {output_file}")
    return message

if __name__ == '__main__':
    extracted = extract_message('stego_dct', max_bits=40)
    print(f"Final extracted message: {extracted}")